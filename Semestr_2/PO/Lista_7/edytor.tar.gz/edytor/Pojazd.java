// Kamil Michalak
// Pracownia PO, czwartek, s. 108
// L5, z4, Pojazdy
// Pojazd
// Pojazd.java
// 2018-04-12

public class Pojazd
{
    public String marka;
    public String kolor;
    public int rocznik;

    public String toString()
    {
        return "";
    }
}