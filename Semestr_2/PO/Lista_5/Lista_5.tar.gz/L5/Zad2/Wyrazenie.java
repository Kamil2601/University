// Kamil Michalak
// Pracownia PO, czwartek, s. 108
// L5, z2, Wyrazenia w drzewach
// Wyrazenie
// Wyrazenie.java
// 2018-03-29

//klasa bazowa
public class Wyrazenie 
{
    public float oblicz()
    {
        return 0;
    }

    public String toString()
    {
        return "";
    }
}